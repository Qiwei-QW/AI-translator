// AI 翻译助手 - 后台 Service Worker
// 职责：调用各主流 AI 服务商的 OpenAI 兼容接口、注册右键菜单、处理各页面发来的翻译请求

// 支持的服务商（均为 OpenAI 兼容的 /chat/completions 接口）
const PROVIDERS = {
  deepseek: {
    name: 'DeepSeek',
    baseUrl: 'https://api.deepseek.com/chat/completions',
    models: ['deepseek-chat', 'deepseek-reasoner'],
    defaultModel: 'deepseek-chat'
  },
  openai: {
    name: 'OpenAI (ChatGPT)',
    baseUrl: 'https://api.openai.com/v1/chat/completions',
    models: ['gpt-4o-mini', 'gpt-4o', 'gpt-4.1-mini', 'gpt-4.1', 'o3-mini'],
    defaultModel: 'gpt-4o-mini'
  },
  qwen: {
    name: '通义千问（阿里）',
    baseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions',
    models: ['qwen-plus', 'qwen-turbo', 'qwen-max', 'qwen-long'],
    defaultModel: 'qwen-plus'
  },
  moonshot: {
    name: 'Kimi（月之暗面）',
    baseUrl: 'https://api.moonshot.cn/v1/chat/completions',
    models: ['moonshot-v1-8k', 'moonshot-v1-32k', 'moonshot-v1-128k', 'kimi-latest'],
    defaultModel: 'moonshot-v1-8k'
  },
  zhipu: {
    name: '智谱 GLM',
    baseUrl: 'https://open.bigmodel.cn/api/paas/v4/chat/completions',
    models: ['glm-4-flash', 'glm-4-air', 'glm-4-plus', 'glm-4-long'],
    defaultModel: 'glm-4-flash'
  },
  gemini: {
    name: 'Google Gemini',
    baseUrl: 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions',
    models: ['gemini-2.5-flash', 'gemini-2.5-pro', 'gemini-2.5-flash-lite'],
    defaultModel: 'gemini-2.5-flash'
  },
  ollama: {
    name: '本地 Ollama',
    baseUrl: 'http://localhost:11434/v1/chat/completions',
    models: [],
    defaultModel: 'qwen2.5',
    local: true
  }
};

const DEFAULT_SETTINGS = {
  provider: 'deepseek',
  apiKeys: {}, // 服务商 id -> API Key
  models: {}, // 服务商 id -> 模型名
  targetLang: '简体中文',
  autoTranslateInput: true
};

const B64_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

// Service Worker 中没有 btoa()，这里手动实现字节数组 -> Base64
function bytesToBase64(bytes) {
  let out = '';
  for (let i = 0; i < bytes.length; i += 3) {
    const b0 = bytes[i];
    const b1 = i + 1 < bytes.length ? bytes[i + 1] : 0;
    const b2 = i + 2 < bytes.length ? bytes[i + 2] : 0;
    out += B64_CHARS[b0 >> 2];
    out += B64_CHARS[((b0 & 3) << 4) | (b1 >> 4)];
    out += i + 1 < bytes.length ? B64_CHARS[((b1 & 15) << 2) | (b2 >> 6)] : '=';
    out += i + 2 < bytes.length ? B64_CHARS[b2 & 63] : '=';
  }
  return out;
}

// ---------- 右键菜单 ----------
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'translate-selection',
    title: 'AI 翻译：翻译选中文本',
    contexts: ['selection']
  });
  chrome.contextMenus.create({
    id: 'translate-page',
    title: 'AI 翻译：翻译整页',
    contexts: ['page']
  });
  chrome.contextMenus.create({
    id: 'restore-page',
    title: 'AI 翻译：还原整页',
    contexts: ['page']
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab?.id) return;
  const typeMap = {
    'translate-selection': 'translateSelection',
    'translate-page': 'translatePage',
    'restore-page': 'restorePage'
  };
  const msgType = typeMap[info.menuItemId];
  if (msgType) {
    chrome.tabs.sendMessage(tab.id, { type: msgType }).catch(() => {});
  }
});

// ---------- 翻译服务 ----------
async function getSettings() {
  const s = await chrome.storage.local.get(DEFAULT_SETTINGS);
  // 兼容旧版设置：把原来的 apiKey / model 迁移到 DeepSeek
  const legacy = await chrome.storage.local.get(['apiKey', 'model']);
  const apiKeys = { ...(s.apiKeys || {}) };
  const models = { ...(s.models || {}) };
  if (legacy.apiKey && !apiKeys.deepseek) apiKeys.deepseek = legacy.apiKey;
  if (legacy.model && !models.deepseek) models.deepseek = legacy.model;
  // 如果保存的服务商已不存在（例如已被移除），回退到 DeepSeek
  const provider = PROVIDERS[s.provider] ? s.provider : 'deepseek';
  return { ...s, apiKeys, models, provider };
}

function buildSystemPrompt(targetLang) {
  return (
    '你是一个专业的翻译引擎。请把用户提供的每一段文本逐段翻译成' + targetLang + '。\n' +
    '严格要求：\n' +
    '1. 输出的段落数量与输入完全一致；\n' +
    '2. 每段单独一行，格式为"编号: 译文"，例如 "1: 你好"；\n' +
    '3. 只输出译文本身，不要输出任何思考过程、解释或额外内容；\n' +
    '4. 如果某段是专有名词、网址或无需翻译的内容，原样输出即可。'
  );
}

async function translateSegments(segments, targetLang, providerOverride, modelOverride) {
  const s = await getSettings();
  const providerId = providerOverride || s.provider || 'deepseek';
  const provider = PROVIDERS[providerId] || PROVIDERS.deepseek;
  const apiKey = (s.apiKeys && s.apiKeys[providerId]) || '';
  const model = modelOverride || (s.models && s.models[providerId]) || provider.defaultModel || '';
  if (!apiKey && !provider.local) {
    throw new Error(`尚未配置 ${provider.name} 的 API Key，请在插件设置中选择服务商并填写`);
  }

  const userContent = segments.map((seg, i) => `${i + 1}: ${seg}`).join('\n');

  const body = {
    model,
    messages: [
      { role: 'system', content: buildSystemPrompt(targetLang) },
      { role: 'user', content: userContent }
    ],
    temperature: 0.3,
    stream: false
  };
  // 不同厂商对输出长度参数命名不同：OpenAI 的 o 系列 / gpt-5 使用 max_completion_tokens
  if (/^o[0-9]|^gpt-5/.test(model)) {
    body.max_completion_tokens = 4096;
  } else {
    body.max_tokens = 4096;
  }
  // 本地 Ollama：显式关闭思考模式（Qwen3 等思考型模型会显著拖慢翻译）
  if (provider.local) {
    body.reasoning_effort = 'none';
  }

  // 保持 Service Worker 存活：本地模型重新加载可能超过 MV3 空闲时限（默认 30 秒），
  // 后台进程被终止会导致响应丢失（表现为"一直正在测试"或"页面长时间无变化"）
  const keepAlive = setInterval(() => {
    chrome.runtime.getPlatformInfo().catch(() => {});
  }, 20000);

  let res;
  try {
    res = await fetch(provider.baseUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify(body)
    });
  } finally {
    clearInterval(keepAlive);
  }

  if (!res.ok) {
    let detail = '';
    try {
      const err = await res.json();
      detail = err?.error?.message || '';
    } catch (_) {}
    throw new Error(`API 请求失败（HTTP ${res.status}）${detail ? '：' + detail : ''}`);
  }

  const data = await res.json();
  const content = data?.choices?.[0]?.message?.content || '';
  return parseTranslations(content, segments);
}

function parseTranslations(content, originals) {
  const parsed = new Array(originals.length).fill(null);
  for (const line of content.split('\n')) {
    const m = line.match(/^\s*[-•*]?\s*(\d+)[:：]\s*(.*)$/);
    if (m) {
      const idx = Number(m[1]) - 1;
      if (idx >= 0 && idx < originals.length) parsed[idx] = m[2];
    }
  }
  const valid = parsed.filter((x) => x !== null).length;
  if (valid === 0) {
    // 模型没有按编号输出时，退化为整段内容
    return [content.trim()];
  }
  // 个别编号缺失时用原文兜底，避免丢失内容
  return parsed.map((p, i) => (p !== null ? p : originals[i]));
}

// ---------- 消息处理 ----------
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    if (message?.type === 'getProviders') {
      return { ok: true, providers: PROVIDERS };
    }
    if (message?.type === 'translateSegments') {
      const translations = await translateSegments(
        message.segments,
        message.targetLang,
        message.provider,
        message.model
      );
      return { ok: true, translations };
    }
    if (message?.type === 'testConnection') {
      const started = Date.now();
      const providerId = message.provider || 'deepseek';
      const provider = PROVIDERS[providerId] || PROVIDERS.deepseek;
      const translations = await translateSegments(
        ['Hello, world! 你好，世界！'],
        message.targetLang || '简体中文',
        providerId,
        message.model
      );
      return {
        ok: true,
        translations,
        elapsedMs: Date.now() - started,
        providerName: provider.name,
        model: message.model || provider.defaultModel
      };
    }
    if (message?.type === 'downloadMhtml') {
      if (!sender.tab?.id) throw new Error('无法获取当前标签页');
      const blob = await chrome.pageCapture.saveAsMHTML({ tabId: sender.tab.id });
      const bytes = new Uint8Array(await blob.arrayBuffer());
      const dataUrl = `data:${blob.type || 'multipart/related'};base64,${bytesToBase64(bytes)}`;
      const downloadId = await chrome.downloads.download({
        url: dataUrl,
        filename: message.filename || 'translated-page.mhtml',
        saveAs: false
      });
      return { ok: true, downloadId };
    }
    return { ok: false, error: '未知的消息类型' };
  })()
    .then(sendResponse)
    .catch((err) => sendResponse({ ok: false, error: err?.message || String(err) }));
  return true; // 保持消息通道打开以支持异步响应
});
