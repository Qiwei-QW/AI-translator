// AI 翻译助手 - 弹窗逻辑：服务商设置、测试连接、快速翻译

const DEFAULT_SETTINGS = {
  provider: 'deepseek',
  apiKeys: {},
  models: {},
  targetLang: '简体中文',
  autoTranslateInput: true
};

const $ = (sel) => document.querySelector(sel);

function withTimeout(promise, ms = 120000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(
      () => reject(new Error(`请求超时（超过 ${Math.round(ms / 1000)} 秒），请检查网络或本地模型是否正常`)),
      ms
    );
    promise.then(
      (v) => { clearTimeout(timer); resolve(v); },
      (e) => { clearTimeout(timer); reject(e); }
    );
  });
}

let providers = {}; // id -> { name, models, defaultModel, local }

async function loadProviders() {
  try {
    const resp = await chrome.runtime.sendMessage({ type: 'getProviders' });
    providers = resp?.ok && resp.providers ? resp.providers : {};
  } catch (_) {
    providers = {};
  }
  if (!Object.keys(providers).length) {
    // 后台不可用时的兜底
    providers = {
      deepseek: { name: 'DeepSeek', models: ['deepseek-chat', 'deepseek-reasoner'], defaultModel: 'deepseek-chat' }
    };
  }
}

function currentProviderId() {
  return $('#providerSelect').value || 'deepseek';
}

function currentModel() {
  // 本地 Ollama 等无预设模型的提供商：直接用文本输入框
  if ($('#modelSelect').hidden) {
    return $('#modelCustom').value.trim() || providers[currentProviderId()]?.defaultModel || '';
  }
  return $('#modelSelect').value === '__custom__'
    ? ($('#modelCustom').value.trim() || providers[currentProviderId()]?.defaultModel || '')
    : $('#modelSelect').value;
}

function fillProviderSelect(savedProvider) {
  const sel = $('#providerSelect');
  sel.innerHTML = '';
  for (const [id, p] of Object.entries(providers)) {
    const opt = document.createElement('option');
    opt.value = id;
    opt.textContent = p.name + (p.local ? '（本地）' : '');
    sel.appendChild(opt);
  }
  sel.value = providers[savedProvider] ? savedProvider : 'deepseek';
}

function fillModelSelect(providerId, savedModels) {
  const p = providers[providerId];
  const sel = $('#modelSelect');
  if (!p?.models?.length) {
    // 本地 Ollama：无预设模型，隐藏下拉框，直接用文本输入框
    const customInput = $('#modelCustom');
    sel.hidden = true;
    customInput.hidden = false;
    customInput.value = savedModels?.[providerId] || '';
    customInput.placeholder = '输入本地模型名称，如 ' + (p?.defaultModel || 'qwen3:8b');
    return;
  }
  sel.hidden = false;
  sel.innerHTML = '';
  if (p?.models?.length) {
    for (const m of p.models) {
      const opt = document.createElement('option');
      opt.value = m;
      opt.textContent = m;
      sel.appendChild(opt);
    }
  }
  const custom = document.createElement('option');
  custom.value = '__custom__';
  custom.textContent = '自定义模型…';
  sel.appendChild(custom);

  const saved = savedModels?.[providerId];
  const customInput = $('#modelCustom');
  if (saved && p?.models?.includes(saved)) {
    sel.value = saved;
    customInput.hidden = true;
  } else if (saved) {
    sel.value = '__custom__';
    customInput.hidden = false;
    customInput.value = saved;
  } else if (p?.defaultModel && p.models?.includes(p.defaultModel)) {
    sel.value = p.defaultModel;
    customInput.hidden = true;
  } else {
    // 例如 Ollama：模型不在预设列表，不预填具体值，用占位提示避免误导
    sel.value = '__custom__';
    customInput.hidden = false;
    customInput.value = '';
    customInput.placeholder = '输入本地模型名称，如 ' + (p?.defaultModel || 'qwen2.5');
  }
}

function applyProviderUi(saved) {
  const pid = currentProviderId();
  const p = providers[pid];
  const isLocal = !!(p && p.local);
  $('#apiKeyWrap').hidden = isLocal;
  $('#apiKeyHint').hidden = !isLocal;
  $('#apiKey').value = (saved.apiKeys && saved.apiKeys[pid]) || '';
  fillModelSelect(pid, saved.models);
}

let statusClearTimer = null;

function updateStatus(text, isError = false) {
  const el = $('#status');
  el.textContent = text;
  el.style.color = isError ? '#c0392b' : '#2e7d32';
  clearTimeout(statusClearTimer);
  statusClearTimer = setTimeout(() => {
    el.textContent = '';
  }, 10000);
}

async function init() {
  await loadProviders();
  const s = await chrome.storage.local.get(DEFAULT_SETTINGS);
  fillProviderSelect(s.provider);
  applyProviderUi(s);
  $('#targetLang').value = s.targetLang;
  $('#autoTranslateInput').checked = s.autoTranslateInput;
}

function debounce(fn, ms = 400) {
  let timer = null;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), ms);
  };
}

// 所有设置修改后自动保存，无需手动点击保存
async function saveSettings() {
  const pid = currentProviderId();
  const s = await chrome.storage.local.get(DEFAULT_SETTINGS);
  const apiKeys = { ...(s.apiKeys || {}), [pid]: $('#apiKey').value.trim() };
  const models = { ...(s.models || {}), [pid]: currentModel() || providers[pid]?.defaultModel || '' };
  await chrome.storage.local.set({
    provider: pid,
    apiKeys,
    models,
    targetLang: $('#targetLang').value,
    autoTranslateInput: $('#autoTranslateInput').checked
  });
}

$('#providerSelect').addEventListener('change', async () => {
  const s = await chrome.storage.local.get(DEFAULT_SETTINGS);
  applyProviderUi(s);
  await saveSettings();
});

$('#modelSelect').addEventListener('change', () => {
  $('#modelCustom').hidden = $('#modelSelect').value !== '__custom__';
  saveSettings();
});

$('#modelCustom').addEventListener('input', debounce(() => saveSettings()));

$('#apiKey').addEventListener('input', debounce(() => saveSettings()));

$('#targetLang').addEventListener('change', () => saveSettings());

$('#autoTranslateInput').addEventListener('change', () => saveSettings());

$('#testBtn').addEventListener('click', async () => {
  const btn = $('#testBtn');
  btn.disabled = true;
  btn.textContent = '测试中…';
  updateStatus('正在测试连接…');
  try {
    const resp = await withTimeout(chrome.runtime.sendMessage({
      type: 'testConnection',
      targetLang: $('#targetLang').value,
      provider: currentProviderId(),
      model: currentModel()
    }));
    if (resp?.ok) {
      updateStatus(`连接成功（${resp.providerName} ${resp.model}，${resp.elapsedMs}ms）：${resp.translations[0]}`);
    } else {
      updateStatus('连接失败：' + (resp?.error || '未知错误'), true);
    }
  } catch (err) {
    updateStatus('连接失败：' + err.message, true);
  } finally {
    btn.disabled = false;
    btn.textContent = '测试连接';
  }
});

$('#quickTranslateBtn').addEventListener('click', async () => {
  const text = $('#quickText').value.trim();
  if (!text) return;
  const result = $('#quickResult');
  result.textContent = '翻译中…';
  try {
    const resp = await withTimeout(chrome.runtime.sendMessage({
      type: 'translateSegments',
      segments: [text],
      targetLang: $('#targetLang').value,
      provider: currentProviderId(),
      model: currentModel()
    }));
    result.textContent = resp?.ok ? resp.translations[0] : '翻译失败：' + (resp?.error || '未知错误');
  } catch (err) {
    result.textContent = '翻译失败：' + err.message;
  }
});

init();
