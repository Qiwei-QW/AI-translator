// AI 翻译助手 - 内容脚本
// 功能：划词翻译、整页翻译、输入框翻译
(() => {
  'use strict';

  // ========== 设置 ==========
  const DEFAULT_SETTINGS = { targetLang: '简体中文', autoTranslateInput: true };
  let settings = { ...DEFAULT_SETTINGS };

  async function loadSettings() {
    settings = { ...DEFAULT_SETTINGS, ...(await chrome.storage.local.get(DEFAULT_SETTINGS)) };
  }
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    for (const key of Object.keys(DEFAULT_SETTINGS)) {
      if (changes[key]) settings[key] = changes[key].newValue;
    }
  });
  loadSettings();

  // ========== 工具函数 ==========
  const cleanText = (s) => (s || '').replace(/\s+/g, ' ').trim();

  function withTimeout(promise, ms) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(
        () => reject(new Error(`等待翻译响应超时（超过 ${Math.round(ms / 1000)} 秒），请检查网络或本地模型是否正常`)),
        ms
      );
      promise.then(
        (v) => { clearTimeout(timer); resolve(v); },
        (e) => { clearTimeout(timer); reject(e); }
      );
    });
  }

  function sendTranslate(segments) {
    return withTimeout(
      chrome.runtime.sendMessage({
        type: 'translateSegments',
        segments,
        targetLang: settings.targetLang
      }),
      180000
    );
  }

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
    } catch (_) {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
    }
  }

  // ========== 划词翻译气泡 ==========
  let lastMouse = { x: 0, y: 0 };
  let pendingSelectionText = '';
  let bubbleHideTimer = null;

  const bubble = document.createElement('div');
  bubble.className = 'ai-tr-bubble';
  bubble.hidden = true;
  bubble.innerHTML = `
    <div class="ai-tr-bubble-actions">
      <button type="button" class="ai-tr-btn ai-tr-btn-primary ai-tr-act-translate">翻译</button>
      <button type="button" class="ai-tr-btn ai-tr-act-copy" hidden>复制</button>
      <button type="button" class="ai-tr-btn ai-tr-act-close" title="关闭">×</button>
    </div>
    <div class="ai-tr-bubble-result" hidden></div>`;
  document.documentElement.appendChild(bubble);

  const bubbleTranslateBtn = bubble.querySelector('.ai-tr-act-translate');
  const bubbleCopyBtn = bubble.querySelector('.ai-tr-act-copy');
  const bubbleCloseBtn = bubble.querySelector('.ai-tr-act-close');
  const bubbleResult = bubble.querySelector('.ai-tr-bubble-result');

  function positionBubble(x, y) {
    const rect = bubble.getBoundingClientRect();
    const margin = 8;
    let left = x + margin;
    let top = y + margin;
    if (left + rect.width > window.innerWidth - margin) {
      left = Math.max(margin, window.innerWidth - rect.width - margin);
    }
    if (top + rect.height > window.innerHeight - margin) {
      top = Math.max(margin, y - rect.height - margin);
    }
    bubble.style.left = left + 'px';
    bubble.style.top = top + 'px';
  }

  function showBubble(x, y, text) {
    clearTimeout(bubbleHideTimer);
    lastMouse = { x, y };
    pendingSelectionText = text;
    bubbleTranslateBtn.disabled = false;
    bubbleTranslateBtn.hidden = false;
    bubbleTranslateBtn.textContent = '翻译';
    bubbleCopyBtn.hidden = true;
    bubbleResult.hidden = true;
    bubbleResult.textContent = '';
    bubble.hidden = false;
    positionBubble(x, y);
  }

  function hideBubble() {
    bubble.hidden = true;
  }

  document.addEventListener('mouseup', (e) => {
    if (bubble.contains(e.target)) return;
    const sel = window.getSelection();
    const text = sel ? cleanText(sel.toString()) : '';
    if (text.length >= 2 && text.length <= 5000) {
      showBubble(e.clientX, e.clientY, text);
    } else {
      hideBubble();
    }
  });

  document.addEventListener('mousedown', (e) => {
    if (!bubble.contains(e.target)) hideBubble();
  });

  window.addEventListener('scroll', hideBubble, true);
  window.addEventListener('resize', hideBubble);

  bubbleCloseBtn.addEventListener('click', hideBubble);

  bubbleTranslateBtn.addEventListener('click', async () => {
    bubbleTranslateBtn.disabled = true;
    bubbleTranslateBtn.textContent = '翻译中…';
    bubbleResult.hidden = false;
    bubbleResult.textContent = '正在翻译，请稍候…';
    try {
      const resp = await sendTranslate([pendingSelectionText]);
      const ok = !!resp?.ok;
      bubbleResult.textContent = ok ? resp.translations[0] : '翻译失败：' + (resp?.error || '未知错误');
      bubbleCopyBtn.hidden = !ok;
      clearTimeout(bubbleHideTimer);
      if (!ok) bubbleHideTimer = setTimeout(hideBubble, 10000);
    } catch (err) {
      bubbleResult.textContent = '翻译失败：' + err.message;
      clearTimeout(bubbleHideTimer);
      bubbleHideTimer = setTimeout(hideBubble, 10000);
    }
    bubbleTranslateBtn.disabled = false;
    bubbleTranslateBtn.textContent = '翻译';
    positionBubble(lastMouse.x, lastMouse.y);
  });

  bubbleCopyBtn.addEventListener('click', async () => {
    await copyText(bubbleResult.textContent);
    bubbleCopyBtn.textContent = '已复制';
    setTimeout(() => { bubbleCopyBtn.textContent = '复制'; }, 1200);
  });

  // ========== 整页翻译 ==========
  const translatedNodes = new Map(); // Text 节点 -> 原文
  let pageStatusBar = null;
  let restoreBar = null;
  let isTranslatingPage = false;
  const pageControl = { paused: false, cancelled: false };
  let pageStatusHideTimer = null;

  function setPageStatus(text, showControls = false) {
    if (!pageStatusBar) {
      pageStatusBar = document.createElement('div');
      pageStatusBar.className = 'ai-tr-page-status';
      pageStatusBar.innerHTML = `
        <span class="ai-tr-page-status-text"></span>
        <button type="button" class="ai-tr-btn ai-tr-page-pause">暂停</button>
        <button type="button" class="ai-tr-btn ai-tr-page-cancel">取消</button>`;
      document.documentElement.appendChild(pageStatusBar);
      pageStatusBar.querySelector('.ai-tr-page-pause').addEventListener('click', togglePagePause);
      pageStatusBar.querySelector('.ai-tr-page-cancel').addEventListener('click', cancelPageTranslation);
    }
    pageStatusBar.querySelector('.ai-tr-page-status-text').textContent = text;
    pageStatusBar.querySelector('.ai-tr-page-pause').hidden = !showControls;
    pageStatusBar.querySelector('.ai-tr-page-cancel').hidden = !showControls;
  }

  function togglePagePause() {
    pageControl.paused = !pageControl.paused;
    const btn = pageStatusBar?.querySelector('.ai-tr-page-pause');
    if (btn) btn.textContent = pageControl.paused ? '继续' : '暂停';
  }

  function cancelPageTranslation() {
    pageControl.cancelled = true;
    pageControl.paused = false; // 让暂停等待循环退出
  }

  async function waitIfPaused() {
    while (pageControl.paused && !pageControl.cancelled) {
      await new Promise((r) => setTimeout(r, 200));
    }
  }

  function finishCancelPageTranslation() {
    isTranslatingPage = false;
    restorePage(); // 撤销已翻译的部分，恢复原文
    hidePageStatus();
  }

  function hidePageStatus() {
    clearTimeout(pageStatusHideTimer);
    if (pageStatusBar) {
      pageStatusBar.remove();
      pageStatusBar = null;
    }
  }

  function showPageError(text) {
    setPageStatus(text, false);
    clearTimeout(pageStatusHideTimer);
    pageStatusHideTimer = setTimeout(hidePageStatus, 10000);
  }

  function collectTextNodes() {
    const nodes = [];
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const el = node.parentElement;
        if (!el) return NodeFilter.FILTER_REJECT;
        if (el.closest(
          'script,style,noscript,code,pre,kbd,samp,var,textarea,input,select,option,svg,canvas,iframe,audio,video,object,.ai-tr-bubble,.ai-tr-input-btn,.ai-tr-input-popup,.ai-tr-page-status,.ai-tr-restore-bar'
        )) {
          return NodeFilter.FILTER_REJECT;
        }
        if (translatedNodes.has(node)) return NodeFilter.FILTER_REJECT;
        if (cleanText(node.nodeValue).length < 2) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    while (walker.nextNode()) nodes.push(walker.currentNode);
    return nodes;
  }

  function chunkNodes(nodes, maxChars = 1200) {
    const chunks = [];
    let current = [];
    let len = 0;
    for (const node of nodes) {
      const text = cleanText(node.nodeValue);
      if (current.length && len + text.length > maxChars) {
        chunks.push(current);
        current = [];
        len = 0;
      }
      current.push(node);
      len += text.length;
    }
    if (current.length) chunks.push(current);
    return chunks;
  }

  async function translatePage() {
    if (isTranslatingPage) return;
    const nodes = collectTextNodes();
    if (!nodes.length) {
      showPageError('未找到可翻译的文本');
      return;
    }
    isTranslatingPage = true;
    pageControl.paused = false;
    pageControl.cancelled = false;
    clearTimeout(pageStatusHideTimer);
    const chunks = chunkNodes(nodes);
    const total = chunks.length;
    const startedAt = Date.now();
    for (let i = 0; i < total; i++) {
      if (pageControl.cancelled) {
        finishCancelPageTranslation();
        return;
      }
      await waitIfPaused();
      if (pageControl.cancelled) {
        finishCancelPageTranslation();
        return;
      }
      const originals = chunks[i].map((n) => cleanText(n.nodeValue));
      const elapsedSec = Math.round((Date.now() - startedAt) / 1000);
      setPageStatus(`正在翻译整页（${i + 1}/${total} 批 · 已用时 ${elapsedSec} 秒）…`, true);
      let resp;
      try {
        resp = await sendTranslate(originals);
      } catch (err) {
        showPageError('整页翻译失败：' + err.message);
        isTranslatingPage = false;
        return;
      }
      if (pageControl.cancelled) {
        finishCancelPageTranslation();
        return;
      }
      if (!resp?.ok) {
        showPageError('整页翻译失败：' + (resp?.error || '未知错误'));
        isTranslatingPage = false;
        return;
      }
      chunks[i].forEach((node, j) => {
        const t = resp.translations[j];
        if (t) {
          translatedNodes.set(node, node.nodeValue);
          node.nodeValue = t;
        }
      });
    }
    isTranslatingPage = false;
    hidePageStatus();
    showRestoreBar(total);
  }

  function showRestoreBar(total) {
    if (restoreBar) return;
    restoreBar = document.createElement('div');
    restoreBar.className = 'ai-tr-restore-bar';
    restoreBar.innerHTML = `
      <span>已翻译 ${total} 批文本</span>
      <button type="button" class="ai-tr-btn ai-tr-dl-txt" title="下载翻译后的纯文本">下载文本</button>
      <button type="button" class="ai-tr-btn ai-tr-btn-primary ai-tr-dl-mhtml" title="下载翻译后的完整快照（保留原样式和图片，.mhtml）">下载快照</button>
      <button type="button" class="ai-tr-btn ai-tr-act-restore">还原原文</button>`;
    restoreBar.querySelector('.ai-tr-act-restore').addEventListener('click', restorePage);
    restoreBar.querySelector('.ai-tr-dl-txt').addEventListener('click', () => downloadContent('txt'));
    restoreBar.querySelector('.ai-tr-dl-mhtml').addEventListener('click', () => downloadContent('mhtml'));
    document.documentElement.appendChild(restoreBar);
  }

  function restorePage() {
    for (const [node, original] of translatedNodes) node.nodeValue = original;
    translatedNodes.clear();
    if (restoreBar) {
      restoreBar.remove();
      restoreBar = null;
    }
  }

  // ========== 下载译文 ==========
  function withHiddenUi(fn) {
    const els = [bubble, inputBtn, inputPopup, pageStatusBar, restoreBar].filter(Boolean);
    const prev = els.map((el) => el.style.display);
    els.forEach((el) => { el.style.display = 'none'; });
    try {
      return fn();
    } finally {
      els.forEach((el, i) => { el.style.display = prev[i]; });
    }
  }

  function getTranslatedText() {
    const header =
      `# ${document.title || ''}\n` +
      `来源：${location.href}\n` +
      `翻译时间：${new Date().toLocaleString()}\n\n`;
    return withHiddenUi(() => header + document.body.innerText);
  }

  function detachPluginUi() {
    const els = [bubble, inputBtn, inputPopup, pageStatusBar, restoreBar].filter(Boolean);
    const attached = els.filter((el) => el.isConnected);
    attached.forEach((el) => el.remove());
    return () => {
      attached.forEach((el) => document.documentElement.appendChild(el));
    };
  }

  async function downloadMhtmlSnapshot() {
    // 先生成快照时临时移除插件自身的 UI，避免混入导出文件
    const reattach = detachPluginUi();
    try {
      const resp = await chrome.runtime.sendMessage({
        type: 'downloadMhtml',
        filename: downloadFilename('mhtml')
      });
      if (!resp?.ok) throw new Error(resp?.error || '快照下载失败');
    } finally {
      reattach();
    }
  }

  function triggerDownload(content, filename, mime) {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    (document.body || document.documentElement).appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  }

  function downloadFilename(ext) {
    const title = (document.title || '').trim().replace(/[\\/:*?"<>|]+/g, '_').slice(0, 60);
    const name = title || 'translated-page';
    const ts = new Date().toISOString().slice(0, 10);
    return `${name}-翻译-${ts}.${ext}`;
  }

  async function downloadContent(format) {
    const btn = restoreBar
      ? restoreBar.querySelector(format === 'txt' ? '.ai-tr-dl-txt' : '.ai-tr-dl-mhtml')
      : null;
    const original = btn ? btn.textContent : '';
    if (btn) {
      btn.disabled = true;
      btn.textContent = '生成中…';
    }
    try {
      if (format === 'txt') {
        const text = getTranslatedText();
        if (!text || text.trim().length === 0) throw new Error('没有可导出的文本');
        triggerDownload(text, downloadFilename('txt'), 'text/plain;charset=utf-8');
      } else if (format === 'mhtml') {
        await downloadMhtmlSnapshot();
      }
      if (btn) btn.textContent = '已开始下载';
      setTimeout(() => {
        if (btn) {
          btn.disabled = false;
          btn.textContent = original;
        }
      }, 1500);
    } catch (err) {
      if (btn) btn.textContent = '下载失败';
      showPageError('下载失败：' + err.message);
      setTimeout(() => {
        if (btn) {
          btn.disabled = false;
          btn.textContent = original;
        }
      }, 3000);
    }
  }

  // ========== 输入框翻译 ==========
  let activeInput = null;
  let inputBtn = null;
  let inputPopup = null;
  let replacedState = null; // { input, original }
  let inputPopupTranslated = '';
  let debounceTimer = null;
  let inputPopupHideTimer = null;

  function isEditable(el) {
    if (!el || !(el instanceof Element)) return false;
    if (el.tagName === 'TEXTAREA') return true;
    if (el.tagName === 'INPUT') {
      const t = (el.type || 'text').toLowerCase();
      return ['text', 'search', 'url', 'email'].includes(t);
    }
    return el.isContentEditable === true;
  }

  function getInputText(el) {
    return el.tagName === 'TEXTAREA' || el.tagName === 'INPUT' ? el.value : el.innerText;
  }

  function setInputText(el, text) {
    if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
      el.value = text;
    } else {
      el.innerText = text;
    }
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }

  function ensureInputUi() {
    if (inputBtn) return;
    inputBtn = document.createElement('button');
    inputBtn.type = 'button';
    inputBtn.className = 'ai-tr-input-btn';
    inputBtn.textContent = '译';
    inputBtn.title = 'AI 翻译输入内容';
    document.documentElement.appendChild(inputBtn);
    inputBtn.addEventListener('click', async () => {
      if (replacedState && replacedState.input === activeInput) {
        setInputText(replacedState.input, replacedState.original);
        replacedState = null;
        inputBtn.textContent = '译';
        inputBtn.title = 'AI 翻译输入内容';
        return;
      }
      await runInputTranslation();
    });

    inputPopup = document.createElement('div');
    inputPopup.className = 'ai-tr-input-popup';
    inputPopup.innerHTML = `
      <div class="ai-tr-input-popup-text"></div>
      <div class="ai-tr-input-popup-actions">
        <button type="button" class="ai-tr-btn ai-tr-pop-replace">替换</button>
        <button type="button" class="ai-tr-btn ai-tr-pop-copy">复制</button>
        <button type="button" class="ai-tr-btn ai-tr-pop-close">关闭</button>
      </div>`;
    document.documentElement.appendChild(inputPopup);
    inputPopup.querySelector('.ai-tr-pop-close').addEventListener('click', hideInputPopup);
    inputPopup.querySelector('.ai-tr-pop-copy').addEventListener('click', () => copyText(inputPopupTranslated));
    inputPopup.querySelector('.ai-tr-pop-replace').addEventListener('click', () => {
      if (!activeInput) return;
      replacedState = { input: activeInput, original: getInputText(activeInput) };
      setInputText(activeInput, inputPopupTranslated);
      inputBtn.textContent = '还';
      inputBtn.title = '还原原文';
      hideInputPopup();
    });
  }

  function positionInputUi() {
    if (!activeInput || !inputBtn) return;
    const rect = activeInput.getBoundingClientRect();
    inputBtn.style.left = Math.max(4, rect.right - 32) + 'px';
    inputBtn.style.top = Math.max(4, rect.bottom - 32) + 'px';
  }

  function showInputButton() {
    ensureInputUi();
    if (replacedState && replacedState.input === activeInput) {
      inputBtn.textContent = '还';
      inputBtn.title = '还原原文';
    } else {
      inputBtn.textContent = '译';
      inputBtn.title = 'AI 翻译输入内容';
    }
    inputBtn.style.display = 'block';
    positionInputUi();
  }

  function hideInputButton() {
    if (inputBtn) inputBtn.style.display = 'none';
  }

  function hideInputPopup() {
    clearTimeout(inputPopupHideTimer);
    if (inputPopup) inputPopup.style.display = 'none';
  }

  function showInputPopup(translated, original) {
    ensureInputUi();
    inputPopupTranslated = translated;
    inputPopup.querySelector('.ai-tr-input-popup-text').textContent = translated;
    const replaceBtn = inputPopup.querySelector('.ai-tr-pop-replace');
    replaceBtn.hidden = original === null;
    clearTimeout(inputPopupHideTimer);
    if (original === null) {
      inputPopupHideTimer = setTimeout(hideInputPopup, 10000);
    }
    const rect = activeInput ? activeInput.getBoundingClientRect() : { left: 8, top: 8 };
    inputPopup.style.display = 'block';
    const pw = inputPopup.offsetWidth;
    let left = rect.left;
    if (left + pw > window.innerWidth - 8) left = Math.max(8, window.innerWidth - pw - 8);
    inputPopup.style.left = left + 'px';
    const ph = inputPopup.offsetHeight;
    let top = rect.top - ph - 8;
    if (top < 8) top = rect.bottom + 8;
    inputPopup.style.top = top + 'px';
  }

  async function runInputTranslation() {
    if (!activeInput) return;
    if (replacedState && replacedState.input === activeInput) return;
    const text = cleanText(getInputText(activeInput));
    if (text.length < 2) return;
    const started = text;
    let resp;
    try {
      resp = await sendTranslate([text]);
    } catch (err) {
      showInputPopup('翻译失败：' + err.message, null);
      return;
    }
    if (!activeInput || cleanText(getInputText(activeInput)) !== started) return;
    if (!resp?.ok) {
      showInputPopup('翻译失败：' + (resp?.error || '未知错误'), null);
      return;
    }
    showInputPopup(resp.translations[0], text);
  }

  document.addEventListener('focusin', (e) => {
    if (isEditable(e.target)) {
      activeInput = e.target;
      showInputButton();
    } else {
      activeInput = null;
      hideInputButton();
      hideInputPopup();
    }
  });

  document.addEventListener('focusout', () => {
    setTimeout(() => {
      const focusInUi =
        (inputBtn && document.activeElement === inputBtn) ||
        (inputPopup && inputPopup.contains(document.activeElement));
      if (!focusInUi) {
        hideInputButton();
        hideInputPopup();
      }
    }, 0);
  });

  document.addEventListener('input', (e) => {
    if (!settings.autoTranslateInput) return;
    if (e.target !== activeInput || !isEditable(e.target)) return;
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(runInputTranslation, 1200);
  });

  window.addEventListener('scroll', () => {
    if (activeInput && inputBtn && inputBtn.style.display === 'block') positionInputUi();
  }, true);

  // ========== 消息监听（右键菜单触发）==========
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === 'translateSelection') {
      const sel = window.getSelection();
      let text = sel ? cleanText(sel.toString()) : '';
      let x = window.innerWidth / 2;
      let y = 80;
      if (text && sel.rangeCount > 0) {
        const rect = sel.getRangeAt(0).getBoundingClientRect();
        x = rect.left + rect.width / 2;
        y = rect.bottom + 4;
      } else if (document.activeElement && isEditable(document.activeElement)) {
        const el = document.activeElement;
        const start = typeof el.selectionStart === 'number' ? el.selectionStart : 0;
        const end = typeof el.selectionEnd === 'number' ? el.selectionEnd : 0;
        const s = cleanText(getInputText(el).substring(start, end));
        if (s.length >= 2) {
          text = s;
          const r = el.getBoundingClientRect();
          x = r.left;
          y = r.top;
        }
      }
      if (text.length >= 2) showBubble(x, y, text);
      sendResponse({ ok: true });
      return;
    }
    if (message?.type === 'translatePage') {
      translatePage().then(() => sendResponse({ ok: true }));
      return true;
    }
    if (message?.type === 'restorePage') {
      restorePage();
      sendResponse({ ok: true });
      return;
    }
    sendResponse({ ok: false, error: '未知消息类型' });
  });
})();
